import UIKit
import PlaygroundSupport
class ViewController:UIViewController{
    var imageView = UIImageView()
    var slider1 = UISlider()
    var slider2 = UISlider()
    
    override func viewDidLoad(){
        super.viewDidLoad()
        imageView.frame = view.bounds.inset(by: UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10))
        imageView.backgroundColor = .green
        view.addSubview(imageView)
        drawStuff()
    }
    
    override func loadView(){
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 375, height: 667))
        view.backgroundColor = .systemBackground
        self.view = view
    }
    
    func drawStuff(){
        let bounds = imageView.bounds
        
        //Some constant points
        let topMiddle = CGPoint(x:bounds.midX, y:bounds.minY)
        let bottomMiddle = CGPoint(x:bounds.midX, y:bounds.maxY)
        let leftMiddle = CGPoint(x:bounds.minX, y:bounds.midY)
        let rightMiddle = CGPoint(x:bounds.maxX, y:bounds.midY)
        
        
        //Set up renderer
        let renderer = UIGraphicsImageRenderer(size: bounds.size)
        let image = renderer.image { rendered in
            let context = rendered.cgContext
            //draw and render the alignment Axes
            context.move(to: topMiddle)  //y-Axis
            context.addLine(to: bottomMiddle) //y-Axis
            context.move(to: leftMiddle)  //x-axis
            context.addLine(to: rightMiddle) //x-axis
            //render in gray dotted lines
            context.setStrokeColor(UIColor.gray.cgColor)
            context.setLineWidth(1)
            context.setLineDash(phase: 0, lengths: [1,1])
            context.strokePath()
            
            //Quad Curve goes here
            context.move(to:leftMiddle)
            context.addQuadCurve(to: rightMiddle, control: CGPoint(x:bounds.minX,y:bounds.minY))
            
            //Two control-point Curves go here
            context.move(to:topMiddle)
            context.addCurve(
                to: bottomMiddle,
                control1: CGPoint(x:bounds.midX - 235,y:bounds.midY - 200),
                control2: CGPoint(x:bounds.midX + 235,y:bounds.midY + 200))
            context.addCurve(
                to: topMiddle,
                control1: CGPoint(x:bounds.midX - 235,y:bounds.midY + 200),
                control2: CGPoint(x:bounds.midX + 235,y:bounds.midY - 200))
        
           
            
            //render the curves.
            context.setLineWidth(2)
            context.setLineDash(phase: 0, lengths: [1,0])
            context.setStrokeColor(UIColor.black.cgColor)
            context.strokePath()
        }
        imageView.image = image
    }
}
PlaygroundPage.current.setLiveView(ViewController())
